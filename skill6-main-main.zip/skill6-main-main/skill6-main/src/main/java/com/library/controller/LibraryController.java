package com.library.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.library.model.Book;

@RestController
public class LibraryController {

    List<Book> bookList = new ArrayList<>();

    // 1 Welcome message
    @GetMapping("/welcome")
    public String welcome() {
        return "Welcome to Online Library System";
    }

    // 2 Return book count
    @GetMapping("/count")
    public int count() {
        return 100;
    }

    // 3 Return price
    @GetMapping("/price")
    public double price() {
        return 499.99;
    }

    // 4 Return list of book titles
    @GetMapping("/books")
    public List<String> books() {

        List<String> list = new ArrayList<>();
        list.add("Spring Boot");
        list.add("Java Programming");
        list.add("Data Structures");

        return list;
    }

    // 5 PathVariable example
    @GetMapping("/books/{id}")
    public String bookById(@PathVariable int id) {
        return "Book details for ID: " + id;
    }

    // 6 RequestParam example
    @GetMapping("/search")
    public String searchBook(@RequestParam String title) {
        return "Searching for book: " + title;
    }

    // 7 Author path variable
    @GetMapping("/author/{name}")
    public String author(@PathVariable String name) {
        return "Books written by: " + name;
    }

    // 8 Add book using POST
    @PostMapping("/addbook")
    public String addBook(@RequestBody Book book) {

        bookList.add(book);

        return "Book added successfully";
    }

    // 9 View books
    @GetMapping("/viewbooks")
    public List<Book> viewBooks() {
        return bookList;
    }
}